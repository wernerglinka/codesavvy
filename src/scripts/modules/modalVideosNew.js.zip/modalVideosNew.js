/*jsLint es6 */
/* global YT*/


var modalVideosNew = (function($, undefined) {
    "use strict";
    let modalVideoTriggers = $(".modal-video");

    let init = function() {
        if (!$("body").hasClass("hasVideo")) {
            return;
        }

        $(window).on("videoAPIReady", function() {
            let player = [];

            modalVideoTriggers.each( function (i) {
                let thisTrigger = $(this);
                let currentVideoContainer = "video" + i;

                // create an overlay for each video
                $("body").append(`<div id="overlay${ i }" class="video-overlay
                "><i class="icon icon-x"></i><div class="responsive-wrapper"><div class="video-container"><div id="${ currentVideoContainer }"></div></div></div></div>`);

                thisTrigger.on('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();

                    let videoID = thisTrigger.data('video-id');
                    let thisOverlay = $('#overlay' + i);
                    let playerVars = {
                        autoplay: 1,
                        controls: 1,
                        enablejsapi: 1,
                        wmode:'opaque',
                        origin:'http://localhost:3000'
                    }
                    
                    thisOverlay.fadeIn( function () {

                        console.log(currentVideoContainer);

                        player[i] = new YT.Player(currentVideoContainer, {
                            videoId: videoID,
                            playerVars: playerVars,
                            events: {
                                'onReady': onPlayerReady,
                                'onStateChange': onPlayerStateChange
                            }
                        });
                        player[i].videoIndex = i;
                    });
                });


            });
        });
    };

    let onPlayerReady = function (event) {
        event.target.playVideo();
    };

    let onPlayerStateChange = function (event) {
        console.log(event.data);
    };


    return {
        init: init
    }
})(jQuery);